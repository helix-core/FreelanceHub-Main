import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SignupclientComponent } from './client-side/signupclient/signupclient.component';
import { SignupfreelancerComponent } from './freelancer-side/signupfreelancer/signupfreelancer.component';
import { RoleSelectionComponent } from './common-pages/role-selection/role-selection.component';
import { LoginComponent } from './common-pages/login/login.component';

const routes: Routes = [
  { path: 'signup/client', component: SignupclientComponent },
  { path: 'signup/freelancer' ,component: SignupfreelancerComponent},
  { path: 'signup/selection', component: RoleSelectionComponent},
  { path: 'login', component: LoginComponent}, // Make sure to create LoginComponent
  { path: '', redirectTo: '/signup/selection', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
