import { NgModule } from '@angular/core';
import { BrowserModule} from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { provideHttpClient,withFetch } from '@angular/common/http';
import { SignupclientComponent } from './client-side/signupclient/signupclient.component';
import { SignupfreelancerComponent } from './freelancer-side/signupfreelancer/signupfreelancer.component';
import { RoleSelectionComponent } from './common-pages/role-selection/role-selection.component';
import { ClientService } from './client.service';
import { RoleService } from './role.service';
import { LoginComponent } from './common-pages/login/login.component';

@NgModule({
  declarations: [
    AppComponent,
    SignupclientComponent,
    SignupfreelancerComponent,
    RoleSelectionComponent,
    LoginComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [
    provideHttpClient(withFetch()),
    ClientService,
    RoleService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
