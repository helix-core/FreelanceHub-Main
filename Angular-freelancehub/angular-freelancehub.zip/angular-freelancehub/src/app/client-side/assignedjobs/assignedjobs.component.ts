import { Component } from '@angular/core';

@Component({
  selector: 'app-assignedjobs',
  standalone: false,
  
  templateUrl: './assignedjobs.component.html',
  styleUrl: './assignedjobs.component.css'
})
export class AssignedjobsComponent {

}
