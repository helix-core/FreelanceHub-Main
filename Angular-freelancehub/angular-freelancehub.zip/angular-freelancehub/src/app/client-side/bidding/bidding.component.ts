import { Component } from '@angular/core';

@Component({
  selector: 'app-bidding',
  standalone: false,
  
  templateUrl: './bidding.component.html',
  styleUrl: './bidding.component.css'
})
export class BiddingComponent {

}
