import { Component } from '@angular/core';

@Component({
  selector: 'app-clientprofile',
  standalone: false,
  
  templateUrl: './clientprofile.component.html',
  styleUrl: './clientprofile.component.css'
})
export class ClientprofileComponent {

}
