import { Component } from '@angular/core';

@Component({
  selector: 'app-edit-client-form',
  standalone: false,
  
  templateUrl: './edit-client-form.component.html',
  styleUrl: './edit-client-form.component.css'
})
export class EditClientFormComponent {

}
