import { Component } from '@angular/core';

@Component({
  selector: 'app-postedjobs',
  standalone: false,
  
  templateUrl: './postedjobs.component.html',
  styleUrl: './postedjobs.component.css'
})
export class PostedjobsComponent {

}
