import { Component } from '@angular/core';

@Component({
  selector: 'app-postjob',
  standalone: false,
  
  templateUrl: './postjob.component.html',
  styleUrl: './postjob.component.css'
})
export class PostjobComponent {

}
