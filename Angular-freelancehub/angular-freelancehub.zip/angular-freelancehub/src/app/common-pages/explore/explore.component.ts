import { Component } from '@angular/core';

@Component({
  selector: 'app-explore',
  standalone: false,
  
  templateUrl: './explore.component.html',
  styleUrl: './explore.component.css'
})
export class ExploreComponent {

}
