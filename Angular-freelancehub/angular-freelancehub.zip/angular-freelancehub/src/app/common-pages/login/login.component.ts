import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  standalone:false
})
export class LoginComponent {
  email: string = '';
  password: string = '';

  constructor(private http: HttpClient, private router: Router) {}

  // onLogin() {
  //   const loginData = { email: this.email, password: this.password };
  //   console.log(loginData);

  //   this.http.post('http://localhost:8080/login', loginData, { observe: 'response' })
  //     .subscribe({
  //       next: (response: any) => {
         
  //         const role = response.headers.get('role');
  //         const userId = response.headers.get('userId');

  //         if (role) {
  //           localStorage.setItem('role', role);
  //           localStorage.setItem('userId', userId!);
  //           alert(`Logged in successfully as: ${role}`);
  //           this.router.navigate(['/dashboard']); // Redirect to the dashboard
  //         }
  //         alert(response.body)
  //       },
  //       error: (error) => {
  //         // Handle login error
  //         alert(error.error);
  //       }
  //     });
  // }
  onLogin() {
    const loginData = { email: this.email, password: this.password };
    console.log(loginData);

    this.http.post('http://localhost:8080/login', loginData, { observe: 'response' })
      .subscribe({
        next: (response: any) => {
          const result = response.body;
          
          if (result.status === 'success') {
            alert(result.message); // Display success message
            this.email = ''; // Clear the email field
            this.password = ''; // Clear the password field
          } else {
            alert(result.message); // Display error message
          }
        },
        error: (error) => {
          // Handle errors in HTTP request
          alert('An error occurred: ' + error.message);
        }
      });
}

}
