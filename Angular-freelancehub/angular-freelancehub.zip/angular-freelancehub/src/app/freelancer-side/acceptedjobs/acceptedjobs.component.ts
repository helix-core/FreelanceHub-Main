import { Component } from '@angular/core';

@Component({
  selector: 'app-acceptedjobs',
  standalone: false,
  
  templateUrl: './acceptedjobs.component.html',
  styleUrl: './acceptedjobs.component.css'
})
export class AcceptedjobsComponent {

}
