import { Component } from '@angular/core';

@Component({
  selector: 'app-appliedjobs',
  standalone: false,
  
  templateUrl: './appliedjobs.component.html',
  styleUrl: './appliedjobs.component.css'
})
export class AppliedjobsComponent {

}
