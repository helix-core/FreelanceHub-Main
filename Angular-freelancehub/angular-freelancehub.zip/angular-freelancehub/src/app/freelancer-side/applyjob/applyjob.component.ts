import { Component } from '@angular/core';

@Component({
  selector: 'app-applyjob',
  standalone: false,
  
  templateUrl: './applyjob.component.html',
  styleUrl: './applyjob.component.css'
})
export class ApplyjobComponent {

}
