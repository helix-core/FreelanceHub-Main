import { Component } from '@angular/core';

@Component({
  selector: 'app-edit-freelancer',
  standalone: false,
  
  templateUrl: './edit-freelancer.component.html',
  styleUrl: './edit-freelancer.component.css'
})
export class EditFreelancerComponent {

}
