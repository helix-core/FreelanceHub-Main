import { Component } from '@angular/core';

@Component({
  selector: 'app-freelancerprofile',
  standalone: false,
  
  templateUrl: './freelancerprofile.component.html',
  styleUrl: './freelancerprofile.component.css'
})
export class FreelancerprofileComponent {

}
