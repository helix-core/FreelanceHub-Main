import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class FreelancerService {

  private apiUrl = 'http://localhost:8080/signup/freelancer';  // Update the endpoint if necessary

  constructor(private http: HttpClient) { }

  registerFreelancer(freelancerData: any): Observable<any> {
    return this.http.post<any>(this.apiUrl, freelancerData);
  }
}